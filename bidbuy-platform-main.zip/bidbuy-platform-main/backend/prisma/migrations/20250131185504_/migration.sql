-- AlterTable
ALTER TABLE "User" ADD COLUMN     "address" TEXT DEFAULT '',
ADD COLUMN     "mobile" TEXT DEFAULT '';
