import React from 'react'

const aboutUs = () => {
  return (
    <div>aboutUs</div>
  )
}

export default aboutUs