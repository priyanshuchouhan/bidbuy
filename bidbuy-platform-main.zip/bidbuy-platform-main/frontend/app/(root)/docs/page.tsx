import React from 'react'

const docsPage = () => {
  return (
    <div>docsPage</div>
  )
}

export default docsPage