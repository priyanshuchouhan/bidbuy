import React from 'react'

const privacyPolicyPage = () => {
  return (
    <div>privacyPolicyPage</div>
  )
}

export default privacyPolicyPage