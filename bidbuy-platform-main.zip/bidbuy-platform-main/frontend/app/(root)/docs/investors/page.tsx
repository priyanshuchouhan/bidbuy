import React from 'react'

const investorPage = () => {
  return (
    <div>investorPage</div>
  )
}

export default investorPage