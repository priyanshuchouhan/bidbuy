import React from 'react'

const termConditionPage = () => {
  return (
    <div>termConditionPage</div>
  )
}

export default termConditionPage