import React from 'react'

const blogsPage = () => {
  return (
    <div>blogsPage</div>
  )
}

export default blogsPage