import React from 'react'

const contactPage = () => {
  return (
    <div>contactPage</div>
  )
}

export default contactPage