import { Icons } from "@/components/icons"

export const categories = [
  {
    title: "Electronics",
    icon: Icons.laptop,
  },
  {
    title: "Fashion",
    icon: Icons.shirt,
  },
  
  
  // Add more categories as needed
]

